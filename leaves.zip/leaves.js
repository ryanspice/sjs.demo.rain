var leavesNumber = 100;
var leavesList = new Array();


var vector = {x:0,y:0};
var leavesType = {
	
	image:0,
	position:Object.create(vector),
	velocity: Object.create(vector),
	
	init:function(){
		
		this.x = Math.random()*window.innerWidth;
	}
}


for (var Leave = leavesNumber; Leave>=0; Leave--)
{
	var L  = leavesList[Leave];
	L = Object.create(leavesType);
	L.init();
}

console.log(leavesList)


var leavesDraw = function(app) {
	
	for (var Leave = leavesNumber; Leave>=0; Leave--)
	{
		var L  = leavesList[Leave];
		
				app.client.visuals.rect_ext(Leave*25,0 ,10,10,1,0.5,false,"#FFFFFF");
				app.client.visuals.circle(Leave*25,0 ,10,10,1,0.5,false,"#FFFFFF");
		//app.visuals.image(L.image,L.position.x,L.position.y)
		//console.log(L);
		//app.client.visuals.rect(L.position.x,L.position.y,25,25,1,"#FFFFFF");
	}
	
}